"""
TZ Label Bridge — local HTTP server for USB direct printing

Runs on localhost:52734. The web app pings /ping to detect if installed,
then POSTs label data to /print. Sends TSPL commands directly to the
default printer using the OS raw print path — same mechanism as Vypar.

Windows: win32print (RAW mode, bypasses print driver rendering)
Mac/Linux: lp -o raw (CUPS raw pass-through)

Usage:
    pip install flask flask-cors
    pip install pywin32  # Windows only
    python bridge.py

Build standalone binary (no Python required on client):
    pyinstaller --onefile --name tz-label-bridge [--noconsole on Windows] bridge.py
"""

import os
import platform
import subprocess
import tempfile

from flask import Flask, jsonify, request
from flask_cors import CORS

BRIDGE_VERSION = "1.0.1"
PORT = 52734

app = Flask(__name__)
CORS(app)


@app.route("/ping")
def ping():
    return jsonify({"status": "ok", "version": BRIDGE_VERSION})


@app.route("/print", methods=["POST"])
def print_labels():
    data = request.get_json(silent=True) or {}

    # Preferred path: FE sends pre-generated TSPL (respects all UI config)
    if "tspl" in data:
        tspl = data["tspl"]
        if not tspl:
            return jsonify({"error": "empty tspl"}), 400
        try:
            _send_to_printer(tspl.encode())
        except Exception as exc:
            return jsonify({"error": str(exc)}), 500
        return jsonify({"status": "printed"})

    # Legacy path: build TSPL from label JSON
    labels = data.get("labels", [])
    if not labels:
        return jsonify({"error": "no labels provided"}), 400
    tspl = _build_tspl_batch(labels)
    try:
        _send_to_printer(tspl.encode())
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500
    return jsonify({"status": "printed", "count": len(labels)})


# ── TSPL builder ──────────────────────────────────────────────────────────────
#
# Coordinate system: 1 dot = 1/203 inch at 8 dpmm.
# Label: 38mm × 25mm = 304 × 200 dots. Hardware margin: 2mm = 16 dots each side.
#
# Layout (dot coordinates):
#   y=8   product model  — FONT "2" 2×2
#   y=32  barcode        — Code128, 56 dots tall
#   y=94  serial no      — FONT "2" 1×1 (smaller)
#   y=106 product details— FONT "2" 2×2
#   y=128 MRP            — FONT "2" 2×2


def _build_tspl_batch(labels: list) -> str:
    parts = []
    for label in labels:
        model = str(label.get("productModel", ""))[:20]
        serial = str(label.get("serialNo", ""))
        details = str(label.get("productDetails", ""))[:20]
        mrp = str(label.get("mrp", ""))

        lines = [
            "SIZE 38 mm, 25 mm",
            "GAP 3 mm, 0 mm",
            "DIRECTION 0,0",
            "CLS",
            f'TEXT 16, 8, "2", 0, 2, 2, "{model}"',
            f'BARCODE 16, 32, "128", 56, 0, 0, 2, 4, "{serial}"',
            f'TEXT 16, 94, "2", 0, 1, 1, "{serial}"',
        ]
        if details:
            lines.append(f'TEXT 16, 106, "2", 0, 2, 2, "{details}"')
        if mrp:
            lines.append(f'TEXT 16, 128, "2", 0, 2, 2, "MRP- Rs. {mrp}/-"')
        lines.append("PRINT 1, 1")
        parts.append("\r\n".join(lines))
    return "\r\n".join(parts)


# ── Platform-aware raw print ──────────────────────────────────────────────────


def _send_to_printer(tspl_bytes: bytes) -> None:
    if platform.system() == "Windows":
        _print_windows(tspl_bytes)
    else:
        _print_unix(tspl_bytes)


def _print_windows(tspl_bytes: bytes) -> None:
    import win32print  # type: ignore[import]

    printer_name = win32print.GetDefaultPrinter()
    h = win32print.OpenPrinter(printer_name)
    try:
        win32print.StartDocPrinter(h, 1, ("TZ Label", None, "RAW"))
        win32print.StartPagePrinter(h)
        win32print.WritePrinter(h, tspl_bytes)
        win32print.EndPagePrinter(h)
        win32print.EndDocPrinter(h)
    finally:
        win32print.ClosePrinter(h)


def _print_unix(tspl_bytes: bytes) -> None:
    with tempfile.NamedTemporaryFile(delete=False, suffix=".tspl") as f:
        f.write(tspl_bytes)
        tmp = f.name
    try:
        subprocess.run(["lp", "-o", "raw", tmp], check=True)
    finally:
        os.unlink(tmp)


# ── Entry point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    print(f"TZ Label Bridge v{BRIDGE_VERSION} — http://127.0.0.1:{PORT}")
    print("Keep this window open while printing. Close it to stop.")
    app.run(host="127.0.0.1", port=PORT)
