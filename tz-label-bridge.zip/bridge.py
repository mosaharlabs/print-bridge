"""
TZ Label Bridge — local HTTP server for USB direct printing

Runs on localhost:52734. The web app pings /ping to detect if installed,
lists installed printers via /printers, then POSTs label data to /print.
Sends TSPL commands directly to a chosen printer using the OS raw print
path — same mechanism as Vypar.

Windows: win32print (RAW mode, bypasses print driver rendering)
Mac/Linux: lp -o raw (CUPS raw pass-through)

Printer selection:
    The web app may pass ?printer=<name> on /print and /print/raw to target a
    specific installed printer. When omitted, the OS default printer is used
    (legacy behaviour — kept so older app versions keep working). Selecting the
    real thermal printer here is what prevents jobs from silently going to a
    "Microsoft Print to PDF" / file-output default and being saved to a file
    instead of printed.

Usage:
    pip install flask flask-cors
    pip install pywin32  # Windows only
    python bridge.py

Build standalone binary (no Python required on client):
    pyinstaller --onefile --name tz-label-bridge [--noconsole on Windows] bridge.py
"""

import os
import platform
import subprocess
import tempfile

from flask import Flask, jsonify, request
from flask_cors import CORS

BRIDGE_VERSION = "1.2.0"
PORT = 52734

app = Flask(__name__)
CORS(app)


@app.route("/ping")
def ping():
    return jsonify({"status": "ok", "version": BRIDGE_VERSION})


@app.route("/printers")
def printers():
    """List installed printers + the OS default, so the web app can let the
    user pick the thermal printer instead of blindly using the default."""
    try:
        names, default = _list_printers()
    except Exception as exc:
        return jsonify({"error": str(exc), "printers": [], "default": None}), 500
    return jsonify({"printers": names, "default": default})


@app.route("/print", methods=["POST"])
def print_labels():
    data = request.get_json(silent=True) or {}
    printer = _requested_printer()

    # Preferred path: FE sends pre-generated TSPL (respects all UI config)
    if "tspl" in data:
        tspl = data["tspl"]
        if not tspl:
            return jsonify({"error": "empty tspl"}), 400
        try:
            _send_to_printer(tspl.encode(), printer)
        except Exception as exc:
            return jsonify({"error": str(exc)}), 500
        return jsonify({"status": "printed", "printer": printer or _safe_default()})

    # Legacy path: build TSPL from label JSON
    labels = data.get("labels", [])
    if not labels:
        return jsonify({"error": "no labels provided"}), 400
    tspl = _build_tspl_batch(labels)
    try:
        _send_to_printer(tspl.encode(), printer)
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500
    return jsonify({"status": "printed", "count": len(labels)})


# V3+ path: raw octet-stream — FE sends a pre-built TSPL job containing inline
# binary BITMAP blocks. We must NOT touch the bytes (JSON would mangle them).
# Target printer (optional) comes in via ?printer= since the body is binary.
@app.route("/print/raw", methods=["POST"])
def print_raw():
    raw = request.get_data(cache=False)
    if not raw:
        return jsonify({"error": "empty body"}), 400
    printer = _requested_printer()
    try:
        _send_to_printer(raw, printer)
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500
    return jsonify(
        {"status": "printed", "bytes": len(raw), "printer": printer or _safe_default()}
    )


def _requested_printer() -> str | None:
    """Target printer name from ?printer= (or X-Printer-Name header). Blank → None."""
    name = request.args.get("printer") or request.headers.get("X-Printer-Name")
    name = (name or "").strip()
    return name or None


def _safe_default() -> str | None:
    try:
        _, default = _list_printers()
        return default
    except Exception:
        return None


# ── TSPL builder ──────────────────────────────────────────────────────────────
#
# Coordinate system: 1 dot = 1/203 inch at 8 dpmm.
# Label: 38mm × 25mm = 304 × 200 dots. Hardware margin: 2mm = 16 dots each side.
#
# Layout (dot coordinates):
#   y=8   product model  — FONT "2" 2×2
#   y=32  barcode        — Code128, 56 dots tall
#   y=94  serial no      — FONT "2" 1×1 (smaller)
#   y=106 product details— FONT "2" 2×2
#   y=128 MRP            — FONT "2" 2×2


def _build_tspl_batch(labels: list) -> str:
    parts = []
    for label in labels:
        model = str(label.get("productModel", ""))[:20]
        serial = str(label.get("serialNo", ""))
        details = str(label.get("productDetails", ""))[:20]
        mrp = str(label.get("mrp", ""))

        lines = [
            "SIZE 38 mm, 25 mm",
            "GAP 3 mm, 0 mm",
            "DIRECTION 0,0",
            "CLS",
            f'TEXT 16, 8, "2", 0, 2, 2, "{model}"',
            f'BARCODE 16, 32, "128", 56, 0, 0, 2, 4, "{serial}"',
            f'TEXT 16, 94, "2", 0, 1, 1, "{serial}"',
        ]
        if details:
            lines.append(f'TEXT 16, 106, "2", 0, 2, 2, "{details}"')
        if mrp:
            lines.append(f'TEXT 16, 128, "2", 0, 2, 2, "MRP- Rs. {mrp}/-"')
        lines.append("PRINT 1, 1")
        parts.append("\r\n".join(lines))
    return "\r\n".join(parts)


# ── Platform-aware printer listing ────────────────────────────────────────────


def _list_printers() -> tuple[list, str | None]:
    if platform.system() == "Windows":
        return _list_printers_windows()
    return _list_printers_unix()


def _list_printers_windows() -> tuple[list, str | None]:
    import win32print  # type: ignore[import]

    flags = win32print.PRINTER_ENUM_LOCAL | win32print.PRINTER_ENUM_CONNECTIONS
    names = [p[2] for p in win32print.EnumPrinters(flags)]
    try:
        default = win32print.GetDefaultPrinter()
    except Exception:
        default = None
    return names, default


def _list_printers_unix() -> tuple[list, str | None]:
    names: list = []
    try:
        out = subprocess.run(
            ["lpstat", "-a"], capture_output=True, text=True, check=False
        ).stdout
        names = [line.split()[0] for line in out.splitlines() if line.strip()]
    except FileNotFoundError:
        pass
    default = None
    try:
        out = subprocess.run(
            ["lpstat", "-d"], capture_output=True, text=True, check=False
        ).stdout.strip()
        # "system default destination: <name>"  |  "no system default destination"
        if ":" in out:
            default = out.split(":", 1)[1].strip() or None
    except FileNotFoundError:
        pass
    return names, default


# ── Platform-aware raw print ──────────────────────────────────────────────────


def _send_to_printer(tspl_bytes: bytes, printer: str | None = None) -> None:
    if platform.system() == "Windows":
        _print_windows(tspl_bytes, printer)
    else:
        _print_unix(tspl_bytes, printer)


def _print_windows(tspl_bytes: bytes, printer: str | None = None) -> None:
    import win32print  # type: ignore[import]

    printer_name = printer or win32print.GetDefaultPrinter()
    h = win32print.OpenPrinter(printer_name)
    try:
        win32print.StartDocPrinter(h, 1, ("TZ Label", None, "RAW"))
        win32print.StartPagePrinter(h)
        win32print.WritePrinter(h, tspl_bytes)
        win32print.EndPagePrinter(h)
        win32print.EndDocPrinter(h)
    finally:
        win32print.ClosePrinter(h)


def _print_unix(tspl_bytes: bytes, printer: str | None = None) -> None:
    with tempfile.NamedTemporaryFile(delete=False, suffix=".tspl") as f:
        f.write(tspl_bytes)
        tmp = f.name
    try:
        cmd = ["lp", "-o", "raw", tmp]
        if printer:
            cmd = ["lp", "-d", printer, "-o", "raw", tmp]
        subprocess.run(cmd, check=True)
    finally:
        os.unlink(tmp)


# ── Entry point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    print(f"TZ Label Bridge v{BRIDGE_VERSION} — http://127.0.0.1:{PORT}")
    print("Keep this window open while printing. Close it to stop.")
    app.run(host="127.0.0.1", port=PORT)
