@echo off
title TZ Label Bridge
cd "%~dp0"

echo Checking Python...
python --version >nul 2>&1
if errorlevel 1 (
    echo Python not found. Installing...

    winget --version >nul 2>&1
    if errorlevel 1 (
        echo Winget not available. Please install Python manually:
        echo https://www.python.org/downloads/
        pause
        exit /b 1
    )

    winget install Python.Python.3.12 -e --silent
    echo Python installed. Please reopen terminal if needed.
)

echo Setting up environment...

if not exist .venv (
    python -m venv .venv
    .venv\Scripts\pip install flask flask-cors pywin32 --quiet
)

echo.
echo TZ Label Bridge is running.
echo Keep this window open while printing labels from the web app.
echo Close this window to stop.
echo.

.venv\Scripts\python bridge.py
pause
